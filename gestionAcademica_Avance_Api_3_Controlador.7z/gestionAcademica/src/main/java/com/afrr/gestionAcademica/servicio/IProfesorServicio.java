package com.afrr.gestionAcademica.servicio;

import java.util.List;
import com.afrr.gestionAcademica.modelo.entidad.profesor;

public interface IProfesorServicio {

	public profesor insertarProfesor(profesor nuevoProfesor);
	public profesor editarProfesor(int idProfesor);
	public void eliminarProfesor(int idProfesor);
	public List<profesor> listarProfesor();
}
