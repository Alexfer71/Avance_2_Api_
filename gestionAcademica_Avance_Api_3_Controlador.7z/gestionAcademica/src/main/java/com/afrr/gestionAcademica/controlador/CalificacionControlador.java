package com.afrr.gestionAcademica.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.afrr.gestionAcademica.modelo.entidad.calificacion;
import com.afrr.gestionAcademica.servicio.ICalificacionServicio;

@RestController
@RequestMapping("/api/calificacion")
public class CalificacionControlador {

	@Autowired
	private ICalificacionServicio servicioCalificacion;

	@GetMapping
	public List<calificacion> listarCalificacion() {
		return servicioCalificacion.listarCalificacion();
	}

	@PostMapping
	public calificacion crearCalificacion(@RequestBody calificacion calificacion) {
		return servicioCalificacion.insertarCalificacion(calificacion);
	}

	@GetMapping("/{id}")
	public calificacion editarCalificacion(@PathVariable int id) {
		return servicioCalificacion.editarCalificacion(id);
	}

	@DeleteMapping("/{id}")
	public void eliminarCalificacion(@PathVariable int id) {
		servicioCalificacion.eliminarCalificacion(id);
	}
}
