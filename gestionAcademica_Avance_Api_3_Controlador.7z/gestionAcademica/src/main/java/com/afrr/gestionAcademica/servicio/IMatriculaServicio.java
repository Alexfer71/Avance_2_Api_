package com.afrr.gestionAcademica.servicio;

import java.util.List;
import com.afrr.gestionAcademica.modelo.entidad.matricula;

public interface IMatriculaServicio {

	public matricula insertarMatricula(matricula nuevaMatricula);
	public matricula editarMatricula(int idMatricula);
	public void eliminarMatricula(int idMatricula);
	public List<matricula> listarMatricula();
}
