package com.afrr.gestionAcademica.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.afrr.gestionAcademica.modelo.entidad.estudiante;
import com.afrr.gestionAcademica.repositorio.IEstudianteRepositorio;
import com.afrr.gestionAcademica.servicio.IEstudianteServicio;

@Service
public class EstudianteServicioImpl implements IEstudianteServicio {

	@Autowired
	public IEstudianteRepositorio estudianteRepositorio;

	@Override
	public estudiante insertarEstudiante(estudiante nuevoEstudiante) {
		return estudianteRepositorio.save(nuevoEstudiante);
	}

	@Override
	public estudiante editarEstudiante(int idEstudiante) {
		return estudianteRepositorio.findById(idEstudiante).orElse(null);
	}

	@Override
	public void eliminarEstudiante(int idEstudiante) {
		estudianteRepositorio.deleteById(idEstudiante);
	}

	@Override
	public List<estudiante> listarEstudiante() {
		return estudianteRepositorio.findAll();
	}
}
