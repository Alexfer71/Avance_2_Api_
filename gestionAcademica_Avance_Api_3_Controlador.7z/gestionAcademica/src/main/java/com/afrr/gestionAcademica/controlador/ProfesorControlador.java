package com.afrr.gestionAcademica.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.afrr.gestionAcademica.modelo.entidad.profesor;
import com.afrr.gestionAcademica.servicio.IProfesorServicio;

@RestController
@RequestMapping("/api/profesor")
public class ProfesorControlador {

	@Autowired
	private IProfesorServicio servicioProfesor;

	@GetMapping
	public List<profesor> listarProfesor() {
		return servicioProfesor.listarProfesor();
	}

	@PostMapping
	public profesor crearProfesor(@RequestBody profesor profesor) {
		return servicioProfesor.insertarProfesor(profesor);
	}

	@GetMapping("/{id}")
	public profesor editarProfesor(@PathVariable int id) {
		return servicioProfesor.editarProfesor(id);
	}

	@DeleteMapping("/{id}")
	public void eliminarProfesor(@PathVariable int id) {
		servicioProfesor.eliminarProfesor(id);
	}
}
