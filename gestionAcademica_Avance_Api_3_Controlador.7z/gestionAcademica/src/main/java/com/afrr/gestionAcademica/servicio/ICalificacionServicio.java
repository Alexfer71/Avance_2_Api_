package com.afrr.gestionAcademica.servicio;

import java.util.List;
import com.afrr.gestionAcademica.modelo.entidad.calificacion;

public interface ICalificacionServicio {

	public calificacion insertarCalificacion(calificacion nuevaCalificacion);
	public calificacion editarCalificacion(int idCalificacion);
	public void eliminarCalificacion(int idCalificacion);
	public List<calificacion> listarCalificacion();
}
