package com.afrr.gestionAcademica.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.afrr.gestionAcademica.modelo.entidad.estudiante;
import com.afrr.gestionAcademica.servicio.IEstudianteServicio;

@RestController
@RequestMapping("/api/estudiante")
public class EstudianteControlador {

	@Autowired
	private IEstudianteServicio servicioEstudiante;

	@GetMapping
	public List<estudiante> listarEstudiante() {
		return servicioEstudiante.listarEstudiante();
	}

	@PostMapping
	public estudiante crearEstudiante(@RequestBody estudiante estudiante) {
		return servicioEstudiante.insertarEstudiante(estudiante);
	}

	@GetMapping("/{id}")
	public estudiante editarEstudiante(@PathVariable int id) {
		return servicioEstudiante.editarEstudiante(id);
	}

	@DeleteMapping("/{id}")
	public void eliminarEstudiante(@PathVariable int id) {
		servicioEstudiante.eliminarEstudiante(id);
	}
}
