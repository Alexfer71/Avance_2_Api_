package com.afrr.gestionAcademica.modelo.entidad;

import java.io.Serializable;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import lombok.Data;

@Entity
@Data
public class calificacion implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idCalificacion;

    private double nota1;
    private double nota2;
    private double notaFinal;
    private int idMatricula;
    
    
    @OneToMany
    @JoinColumn(name = "id_matricula")
    private matricula matricula;
}
