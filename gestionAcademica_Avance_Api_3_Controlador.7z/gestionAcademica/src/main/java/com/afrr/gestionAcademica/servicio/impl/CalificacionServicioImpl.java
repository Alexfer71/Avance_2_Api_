package com.afrr.gestionAcademica.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.afrr.gestionAcademica.modelo.entidad.calificacion;
import com.afrr.gestionAcademica.repositorio.ICalificacionRepositorio;
import com.afrr.gestionAcademica.servicio.ICalificacionServicio;

@Service
public class CalificacionServicioImpl implements ICalificacionServicio {

	@Autowired
	public ICalificacionRepositorio calificacionRepositorio;

	@Override
	public calificacion insertarCalificacion(calificacion nuevaCalificacion) {
		return calificacionRepositorio.save(nuevaCalificacion);
	}

	@Override
	public calificacion editarCalificacion(int idCalificacion) {
		return calificacionRepositorio.findById(idCalificacion).orElse(null);
	}

	@Override
	public void eliminarCalificacion(int idCalificacion) {
		calificacionRepositorio.deleteById(idCalificacion);
	}

	@Override
	public List<calificacion> listarCalificacion() {
		return calificacionRepositorio.findAll();
	}
}
