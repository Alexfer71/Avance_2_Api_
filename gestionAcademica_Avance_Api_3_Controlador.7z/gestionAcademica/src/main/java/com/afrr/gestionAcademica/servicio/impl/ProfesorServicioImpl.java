package com.afrr.gestionAcademica.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.afrr.gestionAcademica.modelo.entidad.profesor;
import com.afrr.gestionAcademica.repositorio.IProfesorRepositorio;
import com.afrr.gestionAcademica.servicio.IProfesorServicio;

@Service
public class ProfesorServicioImpl implements IProfesorServicio {

	@Autowired
	public IProfesorRepositorio profesorRepositorio;

	@Override
	public profesor insertarProfesor(profesor nuevoProfesor) {
		return profesorRepositorio.save(nuevoProfesor);
	}

	@Override
	public profesor editarProfesor(int idProfesor) {
		return profesorRepositorio.findById(idProfesor).orElse(null);
	}

	@Override
	public void eliminarProfesor(int idProfesor) {
		profesorRepositorio.deleteById(idProfesor);
	}

	@Override
	public List<profesor> listarProfesor() {
		return profesorRepositorio.findAll();
	}
}
