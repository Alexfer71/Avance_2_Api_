package com.afrr.gestionAcademica.servicio;

import java.util.List;

import com.afrr.gestionAcademica.modelo.entidad.curso;

public interface ICursoServicio {

    public curso insertarCurso(curso nuevoCurso);
    public curso editarCurso(int idCurso);
    public void eliminarCurso(int idCurso);
    public List<curso> listarCurso();
}
