package com.afrr.gestionAcademica.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.afrr.gestionAcademica.modelo.entidad.matricula;
import com.afrr.gestionAcademica.repositorio.IMatriculaRepositorio;
import com.afrr.gestionAcademica.servicio.IMatriculaServicio;

@Service
public class MatriculaServicioImpl implements IMatriculaServicio {

	@Autowired
	public IMatriculaRepositorio matriculaRepositorio;

	@Override
	public matricula insertarMatricula(matricula nuevaMatricula) {
		return matriculaRepositorio.save(nuevaMatricula);
	}

	@Override
	public matricula editarMatricula(int idMatricula) {
		return matriculaRepositorio.findById(idMatricula).orElse(null);
	}

	@Override
	public void eliminarMatricula(int idMatricula) {
		matriculaRepositorio.deleteById(idMatricula);
	}

	@Override
	public List<matricula> listarMatricula() {
		return matriculaRepositorio.findAll();
	}
}
