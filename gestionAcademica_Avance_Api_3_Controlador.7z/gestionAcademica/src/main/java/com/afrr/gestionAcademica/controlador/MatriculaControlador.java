package com.afrr.gestionAcademica.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.afrr.gestionAcademica.modelo.entidad.matricula;
import com.afrr.gestionAcademica.servicio.IMatriculaServicio;

@RestController
@RequestMapping("/api/matricula")
public class MatriculaControlador {

	@Autowired
	private IMatriculaServicio servicioMatricula;

	@GetMapping
	public List<matricula> listarMatricula() {
		return servicioMatricula.listarMatricula();
	}

	@PostMapping
	public matricula crearMatricula(@RequestBody matricula matricula) {
		return servicioMatricula.insertarMatricula(matricula);
	}

	@GetMapping("/{id}")
	public matricula editarMatricula(@PathVariable int id) {
		return servicioMatricula.editarMatricula(id);
	}

	@DeleteMapping("/{id}")
	public void eliminarMatricula(@PathVariable int id) {
		servicioMatricula.eliminarMatricula(id);
	}
}
