package com.afrr.gestionAcademica.servicio;

import java.util.List;
import com.afrr.gestionAcademica.modelo.entidad.estudiante;

public interface IEstudianteServicio {

	public estudiante insertarEstudiante(estudiante nuevoEstudiante);
	public estudiante editarEstudiante(int idEstudiante);
	public void eliminarEstudiante(int idEstudiante);
	public List<estudiante> listarEstudiante();
}
