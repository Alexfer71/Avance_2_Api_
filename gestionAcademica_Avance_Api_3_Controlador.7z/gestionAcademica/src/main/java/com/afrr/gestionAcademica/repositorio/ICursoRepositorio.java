package com.afrr.gestionAcademica.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.afrr.gestionAcademica.modelo.entidad.curso;

@Repository
@Service
public interface ICursoRepositorio extends JpaRepository<curso, Integer> {

}
