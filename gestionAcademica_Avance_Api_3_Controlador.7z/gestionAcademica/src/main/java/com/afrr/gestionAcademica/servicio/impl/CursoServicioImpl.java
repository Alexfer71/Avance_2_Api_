package com.afrr.gestionAcademica.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.afrr.gestionAcademica.modelo.entidad.curso;
import com.afrr.gestionAcademica.repositorio.ICursoRepositorio;
import com.afrr.gestionAcademica.servicio.ICursoServicio;

@Service
public class CursoServicioImpl implements ICursoServicio {

	@Autowired
	public ICursoRepositorio cursoRepositorio;

	@Override
	public curso insertarCurso(curso nuevoCurso) {
		return cursoRepositorio.save(nuevoCurso);
	}

	@Override
	public curso editarCurso(int idCurso) {
		return cursoRepositorio.findById(idCurso).orElse(null);
	}

	@Override
	public void eliminarCurso(int idCurso) {
		cursoRepositorio.deleteById(idCurso);
	}

	@Override
	public List<curso> listarCurso() {
		return cursoRepositorio.findAll();
	}
}
