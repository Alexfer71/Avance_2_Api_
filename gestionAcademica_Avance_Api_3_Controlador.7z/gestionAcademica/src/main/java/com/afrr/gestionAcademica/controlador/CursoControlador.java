package com.afrr.gestionAcademica.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.afrr.gestionAcademica.modelo.entidad.curso;
import com.afrr.gestionAcademica.servicio.ICursoServicio;

@RestController
@RequestMapping("/api/curso")
public class CursoControlador {

	@Autowired
	private ICursoServicio servicioCurso;

	@GetMapping
	public List<curso> listarCurso() {
		return servicioCurso.listarCurso();
	}

	@PostMapping
	public curso crearCurso(@RequestBody curso curso) {
		return servicioCurso.insertarCurso(curso);
	}
	
	@GetMapping("/{id}")
	public curso editarCurso(@PathVariable int id) {
		return servicioCurso.editarCurso(id);
	} 
	
	@DeleteMapping("/{id}")
	public void eliminarCurso(@PathVariable int id) {
		servicioCurso.eliminarCurso(id);
	}
}
