package com.afrr.gestionAcademica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionAcademicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionAcademicaApplication.class, args);
	}

}
